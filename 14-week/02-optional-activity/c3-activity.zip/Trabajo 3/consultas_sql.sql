-- Corte 3 · Semana 14 — % de entregas retrasadas por semana, con media móvil de 4 semanas (SQLite >= 3.25).
-- Tabla: entrega(fecha_entrega DATE, retrasada INTEGER 0/1, ...), cargada desde salidas/entregas_con_fecha_simulada.csv
-- Semana = lunes-domingo, fechada en su domingo:  date(fecha_entrega, 'weekday 0')  (equivale a resample("W-SUN") de pandas).
-- La media móvil es el promedio simple de los 4 porcentajes semanales, igual que rolling(4).mean() en pandas.

------------------------------------------------------------------------------
-- ANTES · Subconsulta correlacionada sobre la tabla cruda
-- Para cada semana vuelve a leer y agrupar TODAS las entregas de las 4 semanas de la ventana,
-- aplicando una función a la columna de fecha dentro del WHERE (no puede usar índices).
-- Costo ≈ (n.º de semanas) × (n.º de entregas).
------------------------------------------------------------------------------
SELECT w.semana,
       (SELECT AVG(p.pct)
          FROM (SELECT date(e.fecha_entrega, 'weekday 0') AS semana,
                       100.0 * AVG(e.retrasada)           AS pct
                  FROM entrega e
                 WHERE date(e.fecha_entrega, 'weekday 0') BETWEEN date(w.semana, '-21 days') AND w.semana
                 GROUP BY 1) AS p) AS media_movil_4s
  FROM (SELECT DISTINCT date(fecha_entrega, 'weekday 0') AS semana FROM entrega) AS w
 ORDER BY w.semana;

------------------------------------------------------------------------------
-- DESPUÉS · Agregar una sola vez y usar una función de ventana
-- 1) Una CTE agrega por semana en un único recorrido de la tabla (O(n)).
-- 2) AVG(...) OVER (ROWS 3 PRECEDING) promedia sobre ~51 filas semanales, no sobre las entregas.
-- 3) El CASE deja NULL las primeras 3 semanas (ventana incompleta), igual que rolling(4) en pandas.
------------------------------------------------------------------------------
WITH semanal AS (
    SELECT date(fecha_entrega, 'weekday 0') AS semana,
           COUNT(*)                         AS entregas,
           SUM(retrasada)                   AS retrasadas,
           100.0 * AVG(retrasada)           AS pct_retraso
      FROM entrega
     GROUP BY 1
)
SELECT semana, entregas, retrasadas, pct_retraso,
       CASE WHEN COUNT(*) OVER w = 4 THEN AVG(pct_retraso) OVER w END AS media_movil_4s
  FROM semanal
WINDOW w AS (ORDER BY semana ROWS BETWEEN 3 PRECEDING AND CURRENT ROW)
 ORDER BY semana;
