# Análisis temporal y visualización — Retrasos en entregas de última milla

**Actividad calificable · Corte 3 · Semana 14** — Ciencia de Datos · Ingeniería Industrial · CORHUILA 2026-B

| | |
|---|---|
| **Estudiante** | Camila Alejandra Salas Gracia |
| **GitHub** | `casalas-2024a-cell` |
| **Caso** | Logística — retrasos en entregas de última milla (continuación de los Cortes 1 y 2) |
| **Serie analizada** | % de entregas retrasadas por semana (`is_delayed`) |
| **Dataset** | `data/Delivery_Logistics_clean.csv` — 25 000 entregas limpias (Corte 2), *Delivery Logistics Dataset (India – Multi-Partner)* de Kaggle |

> ### ⚠ Supuesto central: el calendario es simulado
> El dataset **no trae ninguna columna de fecha** (ya se había señalado en los README de las semanas 6, 9 y 10), pero una serie temporal necesita un eje de tiempo.
> Para poder aplicar `resample` y media móvil se **asignaron fechas por simulación**: las 25 000 entregas, en el orden de `delivery_id`, se reparten de forma uniforme sobre 357 días
> (lunes 6 de enero a domingo 28 de diciembre de 2025 = **51 semanas completas**, unas 490 entregas por semana).
> Consecuencia: el **método** (resample, media móvil, gráficos, SQL) es el real y reproducible, pero los **patrones temporales no describen una operación real**.
> Como las filas del archivo están en orden aleatorio, lo esperable —y lo que se encuentra— es una serie plana. La comparación por clima, en cambio, no depende de las fechas y sí es un resultado real del dataset.
> Si se consigue una versión del dataset con fecha de entrega, basta cambiar la línea del calendario en `analisis_temporal.py`.

## Contenido de la carpeta

| Archivo | Para qué sirve |
|---|---|
| `README.md` | Este informe: método, resultados, gráficos, SQL/DAX, *Findings* (EN) y referencias |
| `analisis_temporal.py` | Calendario simulado, resample, media móvil, tendencia, estacionalidad y los 2 gráficos |
| `consultas_sql.sql` | Consulta "antes" y "después" de la media móvil en SQL |
| `benchmark_sql.py` | Verifica que el SQL coincide con pandas y mide el tiempo |
| `data/Delivery_Logistics_clean.csv` | Datos de entrada (salida del Corte 2) |
| `salidas/` | `serie_semanal.csv`, `serie_mensual.csv`, `comparacion_por_clima.csv`, `entregas_con_fecha_simulada.csv`, `resumen_resultados.md`, `resultados_sql.md` |
| `img/` | `g1_evolucion_semanal.png`, `g2_comparacion_clima.png` |

---

## 1. Serie temporal: resample y media móvil

**Pregunta:** ¿el porcentaje de entregas retrasadas cambia con el tiempo y hay un patrón que se repita?

**Método.** Con `fecha_entrega` como índice se agregó con `resample("W-SUN")` (semanas lunes–domingo, fechadas en su domingo): número de entregas, número de retrasadas y
**% de retraso = retrasadas / entregas**. Se usa un porcentaje y no un conteo porque es el indicador del caso y es comparable entre semanas. Sobre ese porcentaje se calculó una **media móvil de 4 semanas**
(`rolling(4)`, aprox. un mes), que solo se reporta con 4 semanas completas (por eso las 3 primeras quedan vacías). La media móvil suaviza el ruido de corto plazo
para ver el nivel de fondo (Hyndman & Athanasopoulos, 2021).

```python
semanal = s.resample("W-SUN").agg(entregas=("retrasada", "size"), retrasadas=("retrasada", "sum"))
semanal["pct_retraso"] = 100 * semanal["retrasadas"] / semanal["entregas"]
semanal["media_movil_4s"] = semanal["pct_retraso"].rolling(4).mean()
```

### Tendencia

| Medida | Valor |
|---|---|
| % de retraso global | **26,7 %** |
| Pendiente lineal | **−0,002 puntos porcentuales/semana** (IC 95 %: −0,041 a +0,037); R² = 0,000; p = 0,92 |
| Primeras 4 semanas → últimas 4 | 27,1 % → 24,9 % (−2,2 pp) |
| Media móvil: máximo / mínimo | 28,7 % (semana del 23 nov) / 24,8 % (semana del 21 dic) |
| Variación semanal (desv. estándar) | observada 2,08 pp · esperada solo por azar de muestreo 2,00 pp |

**Lectura.** **No hay tendencia**: la pendiente es prácticamente cero y su intervalo incluye 0 con holgura. La media móvil oscila entre 24,8 % y 28,7 %, una banda estrecha.
La diferencia entre el inicio y el final (−2,2 pp) parece una caída, pero es la que produce el azar: con ~490 entregas por semana, un porcentaje semanal fluctúa unos 2 pp
solo por muestreo, y la variación observada (2,08 pp) es casi idéntica a esa cifra teórica. Es decir, **toda la variación semanal es ruido**, no señal.

### Estacionalidad

| Prueba | Resultado | Conclusión |
|---|---|---|
| Autocorrelación de la serie sin tendencia, lags 1–8 | entre −0,27 y +0,21; banda de ruido ±0,27 | Ningún lag la supera con claridad: **no hay ciclo repetitivo** (Box et al., 2015) |
| % de retraso por mes (ene–dic) | entre 24,9 % y 28,2 %; chi-cuadrado p = 0,48 | Sin diferencia mensual (Pearson, 1900) |
| % de retraso por día de la semana | chi-cuadrado p = 0,80 | Sin efecto del día |

**Lectura.** No se detecta estacionalidad semanal, mensual ni por día de la semana. El lag 6 (−0,27) queda justo en el borde de la banda, algo que se espera por azar al
mirar 8 lags a la vez. Con el calendario simulado este resultado era previsible: ninguna estacionalidad real (temporada de lluvias, fechas pico de compra) puede aparecer si las fechas no vienen del dato.

---

## 2. Dos visualizaciones

### Gráfico 1 — Evolución (línea)

![Evolución semanal](img/g1_evolucion_semanal.png)

**Por qué una línea:** el tiempo es continuo y lo que interesa es la forma de la trayectoria (Knaflic, 2015). Se muestra **la serie real en gris, la media móvil en azul y el
promedio anual como referencia punteada**. **Eje honesto:** el eje Y va de **0 a 100 %**, el rango natural de un porcentaje; un eje recortado (por ejemplo 23–30 %) haría
parecer dramáticas oscilaciones que son puro ruido. **Título = conclusión:** "El % de entregas retrasadas se mantuvo estable en torno a 27 % durante las 51 semanas: sin tendencia ni estacionalidad".
El pie del gráfico y el eje X avisan que las fechas son simuladas.

### Gráfico 2 — Comparación (barras horizontales)

![Comparación por clima](img/g2_comparacion_clima.png)

**Por qué barras:** se comparan magnitudes entre categorías (6 condiciones climáticas); las horizontales dejan leer cómodamente los nombres y ordenar de menor a mayor (Wilke, 2019).
**Eje honesto:** el eje X empieza en **0** (la longitud de la barra es proporcional al valor, condición básica de las barras; Tufte, 2001), cada barra muestra su valor y su tamaño de muestra (*n*),
y una línea punteada marca el promedio de todas las entregas. **Color con propósito:** naranja solo para la condición más crítica (tormenta), azul para las que superan el promedio y gris para las que quedan por debajo.
**Título = conclusión:** "Con tormenta se retrasa 41 % de las entregas, 2,4 veces más que con clima despejado (17 %)".

| Clima | Entregas | % retrasadas |
|---|---|---|
| Frío | 4 158 | 16,0 % |
| Caluroso | 4 130 | 17,1 % |
| Despejado | 4 124 | 17,4 % |
| Niebla | 4 219 | 30,3 % |
| Lluvia | 4 171 | 37,4 % |
| **Tormenta** | 4 198 | **41,4 %** |

La diferencia entre climas es muy significativa (chi-cuadrado, p < 0,001) y **no depende del calendario simulado**. Es coherente con el Corte 2, donde el clima adverso
elevaba el retraso en las entregas `express` y `same_day`; aquí se incluyen todos los modos, por eso los porcentajes son menores (los modos `standard` y `two_day` casi nunca se retrasan en este dataset).
Es una asociación observada, no una prueba de causalidad.

---

## 3. Optimización SQL

Se calcula en SQL la misma serie semanal con media móvil de 4 semanas (archivo [`consultas_sql.sql`](consultas_sql.sql)).

**Antes — subconsulta correlacionada.** Para cada semana vuelve a leer y agrupar las entregas de su ventana, y aplica `date(fecha_entrega,'weekday 0')` dentro del `WHERE`:

```sql
SELECT w.semana,
       (SELECT AVG(p.pct)
          FROM (SELECT date(e.fecha_entrega,'weekday 0') AS semana, 100.0 * AVG(e.retrasada) AS pct
                  FROM entrega e
                 WHERE date(e.fecha_entrega,'weekday 0') BETWEEN date(w.semana,'-21 days') AND w.semana
                 GROUP BY 1) p) AS media_movil_4s
  FROM (SELECT DISTINCT date(fecha_entrega,'weekday 0') AS semana FROM entrega) w
 ORDER BY w.semana;
```

**Después — agregar una vez + función de ventana.**

```sql
WITH semanal AS (
    SELECT date(fecha_entrega,'weekday 0') AS semana, COUNT(*) AS entregas,
           SUM(retrasada) AS retrasadas, 100.0 * AVG(retrasada) AS pct_retraso
      FROM entrega GROUP BY 1
)
SELECT semana, entregas, retrasadas, pct_retraso,
       CASE WHEN COUNT(*) OVER w = 4 THEN AVG(pct_retraso) OVER w END AS media_movil_4s
  FROM semanal
WINDOW w AS (ORDER BY semana ROWS BETWEEN 3 PRECEDING AND CURRENT ROW)
 ORDER BY semana;
```

**Por qué mejora.** La versión "antes" cuesta ≈ (semanas × entregas): el `SCAN e` del plan de ejecución se repite por cada semana de salida. La versión "después" lee la tabla
**una sola vez** (`GROUP BY`) y la media móvil se calcula sobre las 51 filas semanales con una función de ventana (Winand, 2012; SQLite, s. f.). El `CASE` deja `NULL` las
3 primeras semanas, igual que `rolling(4)` en pandas.

| Verificación | Resultado |
|---|---|
| Resultado igual a pandas (51 semanas) | ✔ coincide |
| 25 000 filas (datos reales) | 309 ms → 5,6 ms (**≈ 55×**) |
| 500 000 filas (tabla ×20) | 6 303 ms → 138 ms (**≈ 46×**) |

Tiempos medidos con `benchmark_sql.py` (mejor de 5 ejecuciones, SQLite 3.53); varían según el equipo. La mejora es de más de un orden de magnitud en ambos tamaños y viene de la reescritura (se elimina el recorrido repetido de la tabla), no de un índice. Los planes `EXPLAIN QUERY PLAN` están en [`salidas/resultados_sql.md`](salidas/resultados_sql.md).

### Complemento: las mismas métricas como medidas DAX

> Equivalente para Power BI con una tabla `Calendario` (un día por fila, con una columna `SemanaFin` = domingo de cada semana) relacionada con `Entrega[fecha_entrega]`.
> **No se ejecutó en Power BI** (no está disponible en este entorno); lo verificado es el SQL de arriba.

```dax
% Retraso =
DIVIDE ( CALCULATE ( COUNTROWS ( Entrega ), Entrega[retrasada] = 1 ), COUNTROWS ( Entrega ) )

Media Móvil 4S =
VAR Fin     = MAX ( Calendario[SemanaFin] )
VAR Semanas = FILTER ( ALL ( Calendario[SemanaFin] ), Calendario[SemanaFin] > Fin - 28 && Calendario[SemanaFin] <= Fin )
RETURN IF ( Fin - 27 >= MIN ( Entrega[fecha_entrega] ), AVERAGEX ( Semanas, [% Retraso] ) )   -- vacía si la ventana es incompleta
```

`% Retraso` es la razón base (usa `DIVIDE` para evitar división entre cero); `Media Móvil 4S` promedia esa razón en las 4 últimas semanas, igual que `rolling(4).mean()` (Russo & Ferrari, 2020).

---

## 4. Findings (English)

I resampled 25,000 last-mile deliveries into 51 complete Sunday-ending weeks and computed the weekly percentage of delayed deliveries together with a 4-week moving average.
Because the original dataset has no dates, the calendar was simulated by spreading the deliveries evenly over 2025, so the time patterns below demonstrate the method and do not describe a real operation.
The series shows no trend: the fitted slope is essentially zero (−0.002 percentage points per week, 95% CI −0.041 to +0.037, p = 0.92), and the moving average stays between 24.8% and 28.7% around the overall delay rate of 26.7%.
The weekly standard deviation (2.08 points) almost equals the 2.00 points expected from sampling noise alone, so the small drop between the first and last four weeks is just chance.
I found no seasonality either: the autocorrelation of the detrended series stays within the noise band, and the delay rate does not differ by month (chi-square p = 0.48) or by weekday (p = 0.80).
The first chart is a line chart that plots the weekly delay rate in grey and the 4-week moving average in blue on a y-axis from 0% to 100%, so the flat behaviour is shown at its true scale instead of being exaggerated.
The second chart is a horizontal bar chart comparing delay rates across six weather conditions, and its title states the conclusion: stormy weather delays 41.4% of deliveries, 2.4 times more than clear weather (17.4%).
This weather effect is the only strong and statistically significant pattern in the data (chi-square p < 0.001), and it does not depend on the simulated dates, so operations should focus on adjusting promised delivery times under storms, rain and fog.
These results show association, not causation.

---

## 5. Cómo reproducir

```bash
pip install pandas numpy scipy matplotlib
python analisis_temporal.py     # calendario simulado, serie, estadísticas, gráficos y salidas/*.csv
python benchmark_sql.py         # verifica el SQL contra pandas y mide tiempos
```

> **Nota de entrega:** copia esta carpeta como `14-week/02-optional-activity/Trabajo 3/` dentro de tu fork del repositorio de la clase y sube con
> `git add .`, `git commit -m "Entrega semana 14"`, `git push`, siguiendo el Manual de Entrega por GitHub. Verifica que tu repo de perfil tenga el bloque
> `CONFIG` con `FULL_NAME` y `GITHUB_USER`.

---

## Referencias

Box, G. E. P., Jenkins, G. M., Reinsel, G. C., & Ljung, G. M. (2015). *Time series analysis: Forecasting and control* (5.ª ed.). Wiley.

Hyndman, R. J., & Athanasopoulos, G. (2021). *Forecasting: Principles and practice* (3.ª ed.). OTexts. https://otexts.com/fpp3/

Kaggle. (s. f.). *Delivery Logistics Dataset (India – Multi-Partner)* [Conjunto de datos]. https://www.kaggle.com

Knaflic, C. N. (2015). *Storytelling with data: A data visualization guide for business professionals*. Wiley.

Pearson, K. (1900). On the criterion that a given system of deviations from the probable in the case of a correlated system of variables is such that it can be reasonably supposed to have arisen from random sampling. *The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science, 50*(302), 157–175. https://doi.org/10.1080/14786440009463897

Russo, M., & Ferrari, A. (2020). *The definitive guide to DAX: Business intelligence for Microsoft Power BI, SQL Server Analysis Services, and Excel* (2.ª ed.). Microsoft Press.

SQLite. (s. f.). *Window functions*. https://www.sqlite.org/windowfunctions.html

Tufte, E. R. (2001). *The visual display of quantitative information* (2.ª ed.). Graphics Press.

Wilke, C. O. (2019). *Fundamentals of data visualization*. O'Reilly Media. https://clauswilke.com/dataviz/

Winand, M. (2012). *SQL performance explained*. Markus Winand.
