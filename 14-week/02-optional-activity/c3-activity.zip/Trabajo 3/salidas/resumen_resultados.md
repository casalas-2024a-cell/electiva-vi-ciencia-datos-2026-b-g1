# Resultados del análisis temporal (generado por analisis_temporal.py)

CALENDARIO SIMULADO (el dataset no trae fechas): 2025-01-12 a 2025-12-28 · 51 semanas completas
Entregas: 25,000 · promedio por semana: 490 · % de retraso global: 26.68 %

## Tendencia
- Pendiente lineal: -0.002 puntos porcentuales/semana (IC 95 %: -0.041 a +0.037); R² = 0.000; p = 0.92
- Promedio primeras 4 semanas: 27.1 % · últimas 4: 24.9 % · diferencia: -2.2 pp
- Media móvil 4 s: máximo 28.7 % (2025-11-23) · mínimo 24.8 % (2025-12-21)
- Desviación estándar semanal observada: 2.08 pp · esperada solo por azar de muestreo: 2.00 pp

## Estacionalidad
- Autocorrelación de la serie sin tendencia, lags 1-8: -0.03, +0.03, -0.07, +0.08, -0.19, -0.27, +0.21, +0.05 (banda de ruido ±0.27)
- % de retraso por mes: 1: 27.0, 2: 26.7, 3: 26.5, 4: 26.6, 5: 25.3, 6: 26.6, 7: 27.8, 8: 27.4, 9: 27.1, 10: 26.0, 11: 28.2, 12: 24.9 · chi-cuadrado p = 0.48
- % de retraso por día de la semana: chi-cuadrado p = 0.80

## Comparación por clima (% de retraso)
                   size  pct_retraso
weather_condition                   
cold               4158         16.0
hot                4130         17.1
clear              4124         17.4
foggy              4219         30.3
rainy              4171         37.4
stormy             4198         41.4
chi-cuadrado clima × retraso: p = 1.02e-290 · tormenta/despejado = 2.38×
