# Resultados SQL (generado por benchmark_sql.py)

## Corrección
- Consulta DESPUÉS igual a pandas en las 51 semanas: **True**
- Consulta ANTES igual a pandas desde la semana 4 (las 3 primeras no tienen ventana completa): **True**

## Plan de ejecución (EXPLAIN QUERY PLAN)

**ANTES**
```
CO-ROUTINE w
SCAN entrega
USE TEMP B-TREE FOR DISTINCT
SCAN w
CORRELATED SCALAR SUBQUERY 2
CO-ROUTINE p
SCAN e
USE TEMP B-TREE FOR GROUP BY
SCAN p
USE TEMP B-TREE FOR ORDER BY
```

**DESPUÉS**
```
CO-ROUTINE (subquery-3)
CO-ROUTINE semanal
SCAN entrega
USE TEMP B-TREE FOR GROUP BY
SCAN semanal
USE TEMP B-TREE FOR ORDER BY
SCAN (subquery-3)
```

## Tiempo (mejor de 5 ejecuciones, ms)

| Tabla | Filas | ANTES | DESPUÉS | Mejora |
|---|---|---|---|---|
| Datos reales | 25,000 | 309.0 | 5.6 | 55.4× |
| Ampliada ×20 | 500,000 | 6,302.6 | 138.1 | 45.6× |

Nota: los tiempos dependen del equipo; lo que importa es el orden de magnitud y cómo crece con el tamaño de la tabla.
