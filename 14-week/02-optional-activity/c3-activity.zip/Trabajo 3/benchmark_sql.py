"""Comprueba y mide las dos consultas de consultas_sql.sql en SQLite.

1) Verifica que ambas dan la misma media móvil que pandas (salidas/serie_semanal.csv).
2) Muestra el plan de ejecución (EXPLAIN QUERY PLAN) de cada una.
3) Mide el tiempo (mejor de 5) con las 25 000 entregas y con una tabla ampliada (×20 = 500 000 filas).

Uso:  python benchmark_sql.py      (desde esta carpeta; ejecutar antes analisis_temporal.py)
"""
import sqlite3
import time
from pathlib import Path

import pandas as pd

AQUI = Path(__file__).resolve().parent
sql = (AQUI / "consultas_sql.sql").read_text(encoding="utf-8")
ANTES = sql[sql.index("SELECT w.semana"):].split(";")[0] + ";"
DESPUES = sql[sql.index("WITH semanal"):]

PANDAS = pd.read_csv(AQUI / "salidas" / "serie_semanal.csv")["media_movil_4s"].to_numpy()
df = pd.read_csv(AQUI / "salidas" / "entregas_con_fecha_simulada.csv", usecols=["fecha_entrega", "retrasada"])


def crear(replicas: int) -> sqlite3.Connection:
    con = sqlite3.connect(":memory:")
    pd.concat([df] * replicas, ignore_index=True).to_sql("entrega", con, index=False)
    return con


def tiempo(con, consulta, veces=5):
    mejor, filas = 1e9, None
    for _ in range(veces):
        t0 = time.perf_counter()
        filas = con.execute(consulta).fetchall()
        mejor = min(mejor, time.perf_counter() - t0)
    return mejor * 1000, filas


out = ["# Resultados SQL (generado por benchmark_sql.py)\n"]

# --- 1. Corrección
con = crear(1)
_, f_antes = tiempo(con, ANTES, 1)
_, f_desp = tiempo(con, DESPUES, 1)
mm_antes = [r[1] for r in f_antes]
mm_desp = [r[4] for r in f_desp]
assert len(mm_antes) == len(mm_desp) == len(PANDAS) == 51
ok_desp = all((a is None and pd.isna(b)) or (a is not None and abs(a - b) < 1e-9) for a, b in zip(mm_desp, PANDAS))
# La consulta "antes" no deja NULL en las 3 primeras semanas: se compara desde la 4.ª.
ok_antes = all(abs(a - b) < 1e-9 for a, b in zip(mm_antes[3:], PANDAS[3:]))
out.append(f"## Corrección\n- Consulta DESPUÉS igual a pandas en las {len(PANDAS)} semanas: **{ok_desp}**\n"
           f"- Consulta ANTES igual a pandas desde la semana 4 (las 3 primeras no tienen ventana completa): **{ok_antes}**\n")
assert ok_desp and ok_antes

# --- 2. Planes
out.append("## Plan de ejecución (EXPLAIN QUERY PLAN)\n")
for nombre, q in (("ANTES", ANTES), ("DESPUÉS", DESPUES)):
    plan = con.execute("EXPLAIN QUERY PLAN " + q.strip().rstrip(";")).fetchall()
    out.append(f"**{nombre}**\n```\n" + "\n".join(r[3] for r in plan) + "\n```\n")

# --- 3. Tiempos
out.append("## Tiempo (mejor de 5 ejecuciones, ms)\n\n| Tabla | Filas | ANTES | DESPUÉS | Mejora |\n|---|---|---|---|---|")
for etiqueta, rep in (("Datos reales", 1), ("Ampliada ×20", 20)):
    c = crear(rep)
    n = c.execute("SELECT COUNT(*) FROM entrega").fetchone()[0]
    t_a, _ = tiempo(c, ANTES)
    t_d, _ = tiempo(c, DESPUES)
    out.append(f"| {etiqueta} | {n:,} | {t_a:,.1f} | {t_d:,.1f} | {t_a / t_d:,.1f}× |")
out.append("\nNota: los tiempos dependen del equipo; lo que importa es el orden de magnitud y cómo crece con el tamaño de la tabla.")

texto = "\n".join(out) + "\n"
(AQUI / "salidas" / "resultados_sql.md").write_text(texto, encoding="utf-8")
print(texto)
