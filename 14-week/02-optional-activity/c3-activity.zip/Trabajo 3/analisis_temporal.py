"""Corte 3 · Semana 14 — Análisis temporal y visualización (caso logística de última milla).

Serie: % de entregas retrasadas por semana (indicador central del caso, Cortes 1 y 2).

IMPORTANTE — el dataset (Delivery Logistics, India) NO trae fecha. Para poder aplicar resample
se le asigna un CALENDARIO SIMULADO: las 25 000 entregas, en el orden de delivery_id, se reparten
de forma uniforme sobre 357 días (lunes 2025-01-06 a domingo 2025-12-28 = 51 semanas completas).
Por eso la serie sirve para demostrar el método, pero NO describe una operación real.

Uso:  python analisis_temporal.py      (desde esta carpeta)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

AQUI = Path(__file__).resolve().parent
DATOS = AQUI / "data" / "Delivery_Logistics_clean.csv"
IMG, SAL = AQUI / "img", AQUI / "salidas"
IMG.mkdir(exist_ok=True)
SAL.mkdir(exist_ok=True)

INICIO, DIAS, VENTANA = pd.Timestamp("2025-01-06"), 357, 4   # lunes; 51 semanas; media móvil de 4 semanas

# ---------------------------------------------------------------- 1. Carga + calendario simulado
df = pd.read_csv(DATOS).sort_values("delivery_id").reset_index(drop=True)
assert len(df) == 25000 and df["delivery_id"].is_unique
df["fecha_entrega"] = INICIO + pd.to_timedelta((np.arange(len(df)) * DIAS // len(df)), unit="D")
df["retrasada"] = df["is_delayed"].astype(int)
df[["delivery_id", "fecha_entrega", "weather_condition", "delivery_mode", "retrasada", "delivery_time_hours"]] \
    .to_csv(SAL / "entregas_con_fecha_simulada.csv", index=False)

# ---------------------------------------------------------------- 2. Resample + media móvil
s = df.set_index("fecha_entrega")
semanal = s.resample("W-SUN").agg(entregas=("retrasada", "size"), retrasadas=("retrasada", "sum"))
semanal["pct_retraso"] = 100 * semanal["retrasadas"] / semanal["entregas"]
semanal["media_movil_4s"] = semanal["pct_retraso"].rolling(VENTANA).mean()
mensual = s.resample("MS").agg(entregas=("retrasada", "size"), retrasadas=("retrasada", "sum"))
mensual["pct_retraso"] = 100 * mensual["retrasadas"] / mensual["entregas"]
semanal.to_csv(SAL / "serie_semanal.csv", index_label="semana_termina")
mensual.to_csv(SAL / "serie_mensual.csv", index_label="mes")
assert len(semanal) == 51 and (semanal["entregas"] > 0).all()

# ---------------------------------------------------------------- 3. Tendencia
x = np.arange(len(semanal))
reg = stats.linregress(x, semanal["pct_retraso"])
glob = 100 * df["retrasada"].mean()
mm = semanal["media_movil_4s"].dropna()
ini, fin = semanal["pct_retraso"].iloc[:VENTANA].mean(), semanal["pct_retraso"].iloc[-VENTANA:].mean()
sd_esp = 100 * np.sqrt(glob / 100 * (1 - glob / 100) / semanal["entregas"].mean())   # ruido solo por muestreo

# ---------------------------------------------------------------- 4. Estacionalidad
resid = semanal["pct_retraso"] - (reg.intercept + reg.slope * x)
acf = [resid.autocorr(k) for k in range(1, 9)]
cota = 1.96 / np.sqrt(len(resid))
tab_mes = pd.crosstab(df["fecha_entrega"].dt.month, df["retrasada"])
chi_mes = stats.chi2_contingency(tab_mes)
tab_dia = pd.crosstab(df["fecha_entrega"].dt.dayofweek, df["retrasada"])
chi_dia = stats.chi2_contingency(tab_dia)

# ---------------------------------------------------------------- 5. Comparación por clima
clima = df.groupby("weather_condition")["retrasada"].agg(["mean", "size"])
clima["pct_retraso"] = 100 * clima["mean"]
clima = clima.sort_values("pct_retraso")
chi_clima = stats.chi2_contingency(pd.crosstab(df["weather_condition"], df["retrasada"]))
clima[["size", "pct_retraso"]].rename(columns={"size": "entregas"}).to_csv(SAL / "comparacion_por_clima.csv", index_label="clima")
razon = clima.loc["stormy", "pct_retraso"] / clima.loc["clear", "pct_retraso"]

# ---------------------------------------------------------------- 6. Gráficos
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
AZUL, GRIS, NAR = "#1f5fa8", "#9aa5b1", "#d9822b"
ES = {"clear": "Despejado", "cold": "Frío", "hot": "Caluroso", "foggy": "Niebla", "rainy": "Lluvia", "stormy": "Tormenta"}

# Gráfico 1 — evolución (línea; eje Y 0–100 %)
fig, ax = plt.subplots(figsize=(9, 4.6))
ax.plot(semanal.index, semanal["pct_retraso"], color=GRIS, marker="o", ms=3.5, lw=1.2, label="% de retraso semanal")
ax.plot(semanal.index, semanal["media_movil_4s"], color=AZUL, lw=2.8, label=f"Media móvil de {VENTANA} semanas")
ax.axhline(glob, color="#555", lw=1, ls="--", label=f"Promedio anual ({glob:.1f} %)".replace(".", ","))
ax.set_ylim(0, 100)
ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(decimals=0))
ax.set_ylabel("Entregas retrasadas (%)")
ax.set_xlabel("Semana (cada punto = semana lunes–domingo, fechada en su domingo; calendario simulado)")
ax.set_title(f"El % de entregas retrasadas se mantuvo estable en torno a {glob:.0f} %\n"
             f"durante las 51 semanas: sin tendencia ni estacionalidad", loc="left", fontsize=11, fontweight="bold")
ax.legend(frameon=False, loc="upper right")
ax.grid(axis="y", alpha=.25)
fig.text(0.01, 0.005, "Fuente: Delivery_Logistics_clean.csv (25 000 entregas). Fechas asignadas por simulación (el dataset no las trae). Eje Y de 0 a 100 %.",
         fontsize=7.5, color="#555")
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig(IMG / "g1_evolucion_semanal.png", dpi=170)
plt.close(fig)

# Gráfico 2 — comparación (barras horizontales; eje X 0–100 %)
fig, ax = plt.subplots(figsize=(9, 4.6))
cols = [NAR if c == "stormy" else (AZUL if v > glob else GRIS) for c, v in clima["pct_retraso"].items()]
barras = ax.barh([ES[c] for c in clima.index], clima["pct_retraso"], color=cols)
for b, v, n in zip(barras, clima["pct_retraso"], clima["size"]):
    etiqueta = f"{v:.1f} %".replace(".", ",") + f"   (n = {n:,})".replace(",", " ")
    ax.text(v + 1, b.get_y() + b.get_height() / 2, etiqueta, va="center", fontsize=9,
            bbox=dict(facecolor="white", edgecolor="none", pad=1.5))
ax.axvline(glob, color="#555", lw=1, ls="--", zorder=0, label=f"Promedio de todas las entregas ({glob:.1f} %)".replace(".", ","))
ax.legend(frameon=False, loc="lower right")
ax.set_xlim(0, 100)
ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(decimals=0))
ax.set_xlabel("Entregas retrasadas (%)")
ax.set_title(f"Con tormenta se retrasa {clima.loc['stormy', 'pct_retraso']:.0f} % de las entregas,\n"
             f"{str(round(razon,1)).replace('.', ',')} veces más que con clima despejado ({clima.loc['clear', 'pct_retraso']:.0f} %)", loc="left", fontsize=11, fontweight="bold")
ax.grid(axis="x", alpha=.25)
fig.text(0.01, 0.005, "Fuente: Delivery_Logistics_clean.csv. Todas las entregas, todos los modos. Naranja = tormenta; azul = sobre el promedio; gris = bajo el promedio. Eje X de 0 a 100 %.",
         fontsize=7.5, color="#555")
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig(IMG / "g2_comparacion_clima.png", dpi=170)
plt.close(fig)

# ---------------------------------------------------------------- 7. Resumen
res = f"""# Resultados del análisis temporal (generado por analisis_temporal.py)

CALENDARIO SIMULADO (el dataset no trae fechas): {semanal.index[0].date()} a {semanal.index[-1].date()} · {len(semanal)} semanas completas
Entregas: {len(df):,} · promedio por semana: {semanal['entregas'].mean():.0f} · % de retraso global: {glob:.2f} %

## Tendencia
- Pendiente lineal: {reg.slope:+.3f} puntos porcentuales/semana (IC 95 %: {reg.slope - 1.96*reg.stderr:+.3f} a {reg.slope + 1.96*reg.stderr:+.3f}); R² = {reg.rvalue**2:.3f}; p = {reg.pvalue:.2f}
- Promedio primeras 4 semanas: {ini:.1f} % · últimas 4: {fin:.1f} % · diferencia: {fin-ini:+.1f} pp
- Media móvil 4 s: máximo {mm.max():.1f} % ({mm.idxmax().date()}) · mínimo {mm.min():.1f} % ({mm.idxmin().date()})
- Desviación estándar semanal observada: {semanal['pct_retraso'].std():.2f} pp · esperada solo por azar de muestreo: {sd_esp:.2f} pp

## Estacionalidad
- Autocorrelación de la serie sin tendencia, lags 1-8: {', '.join(f'{a:+.2f}' for a in acf)} (banda de ruido ±{cota:.2f})
- % de retraso por mes: {', '.join(f'{m}: {v:.1f}' for m, v in (100*df.groupby(df['fecha_entrega'].dt.month)['retrasada'].mean()).items())} · chi-cuadrado p = {chi_mes[1]:.2f}
- % de retraso por día de la semana: chi-cuadrado p = {chi_dia[1]:.2f}

## Comparación por clima (% de retraso)
{clima[['size', 'pct_retraso']].round(1).to_string()}
chi-cuadrado clima × retraso: p = {chi_clima[1]:.2e} · tormenta/despejado = {razon:.2f}×
"""
(SAL / "resumen_resultados.md").write_text(res, encoding="utf-8")
print(res)
